<%-- 
    Document   : game
    Created on : Feb 2, 2026, 9:18:57 AM
    Author     : kiet
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html lang="vi">
    <head>
        <title>FIVEPIGS - Game</title>
        <jsp:include page="head.jsp" />
    </head>
    <body>

        <jsp:include page="/UI/sidebar.jsp" />
        <div class="main-content">
            <jsp:include page="/UI/header.jsp" />
            <div class="content-section">
                <div class="fixed-layout-grid">
                    <div class="left-column" style="height: var(--sidebar-total-height);">
                        <div class="featured-banner"
                             style="height:100%; background-image: url('https://wallpapers.com/images/hd/call-of-duty-black-ops-cold-war-key-art-4k-gaming-wallpaper-7c64b6w3a2a6z8y5.jpg'); padding:0;">
                            <div
                                style="background: linear-gradient(to top, rgba(0,0,0,0.9), transparent); height:100%; width:100%; display:flex; flex-direction:column; justify-content:flex-end; padding:30px;">
                                <span
                                    style="background: orange; color: black; width:fit-content; padding: 4px 10px; font-size: 12px; font-weight: 700; border-radius: 4px; margin-bottom:10px;">SEASON
                                    01</span>
                                <h1 style="font-size: 40px; margin-bottom: 10px;">Call of Duty: Black Ops 7</h1>
                                <p style="opacity: 0.8; max-width: 500px; margin-bottom: 20px;">Drop in with Fallout in
                                    Season 01 Reloaded.</p>
                                <button
                                    style="padding: 12px 30px; border: none; background: var(--primary-color); color: white; font-weight: 700; border-radius: 8px; cursor: pointer; width:fit-content;">Play
                                    Now</button>
                            </div>
                        </div>
                    </div>
                    <div class="right-column-box" style="background: #1a1a2e; color: white;">
                        <h3 style="margin-bottom:10px;">Now Available</h3>
                        <p style="font-size:12px; opacity:0.7; margin-bottom:20px;">Top Seller this week</p>
                        <div style="margin-top:auto; background:rgba(255,255,255,0.1); padding:15px; border-radius:12px;">
                            <h4 style="margin-bottom:5px;">Black Ops 6</h4>
                            <p style="font-size:12px; opacity:0.8;">Action • FPS</p>
                        </div>
                    </div>
                </div>

                <div class="section-header">
                    Open World Exploration Games <i class="fa-solid fa-chevron-right"></i>
                </div>

                <div class="app-list-grid">
                    <div class="app-list-item">
                        <img src="https://image.api.playstation.com/vulcan/img/rnd/202010/2119/cedX5oxDvA95beXB9mV9K1K6.png"
                             class="app-icon-lg">
                        <div class="app-details">
                            <div class="app-name">Minecraft</div>
                            <div class="app-meta"><i class="fa-solid fa-star"></i> 4.0 | Social</div>
                        </div>
                        <div class="app-price">Free</div>
                    </div>
                    <div class="app-list-item">
                        <img src="https://image.api.playstation.com/vulcan/img/rnd/202010/2119/cedX5oxDvA95beXB9mV9K1K6.png"
                             class="app-icon-lg">
                        <div class="app-details">
                            <div class="app-name">Minecraft</div>
                            <div class="app-meta"><i class="fa-solid fa-star"></i> 4.0 | Social</div>
                        </div>
                        <div class="app-price">Free</div>
                    </div>
                    <div class="app-list-item">
                        <img src="https://image.api.playstation.com/vulcan/img/rnd/202010/2119/cedX5oxDvA95beXB9mV9K1K6.png"
                             class="app-icon-lg">
                        <div class="app-details">
                            <div class="app-name">Minecraft</div>
                            <div class="app-meta"><i class="fa-solid fa-star"></i> 4.0 | Social</div>
                        </div>
                        <div class="app-price">Free</div>
                    </div>
                    <div class="app-list-item">
                        <img src="https://image.api.playstation.com/vulcan/img/rnd/202010/2119/cedX5oxDvA95beXB9mV9K1K6.png"
                             class="app-icon-lg">
                        <div class="app-details">
                            <div class="app-name">Minecraft</div>
                            <div class="app-meta"><i class="fa-solid fa-star"></i> 4.0 | Social</div>
                        </div>
                        <div class="app-price">Free</div>
                    </div>
                    <div class="app-list-item">
                        <img src="https://image.api.playstation.com/vulcan/img/rnd/202010/2119/cedX5oxDvA95beXB9mV9K1K6.png"
                             class="app-icon-lg">
                        <div class="app-details">
                            <div class="app-name">Minecraft</div>
                            <div class="app-meta"><i class="fa-solid fa-star"></i> 4.0 | Social</div>
                        </div>
                        <div class="app-price">Free</div>
                    </div>
                    <div class="app-list-item">
                        <img src="https://image.api.playstation.com/vulcan/img/rnd/202010/2119/cedX5oxDvA95beXB9mV9K1K6.png"
                             class="app-icon-lg">
                        <div class="app-details">
                            <div class="app-name">Minecraft</div>
                            <div class="app-meta"><i class="fa-solid fa-star"></i> 4.0 | Social</div>
                        </div>
                        <div class="app-price">Free</div>
                    </div>
                </div>
            </div>
        </div>

    </body>
</html>