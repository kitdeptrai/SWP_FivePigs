<%-- 
    Document   : app
    Created on : Feb 2, 2026, 9:19:15 AM
    Author     : kiet
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
 <div class="content-section">
            <div class="fixed-layout-grid">
                <div class="left-column" style="height: var(--sidebar-total-height);">
                    <div class="featured-banner"
                        style="height:100%; background-image: url('https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop'); padding:0;">
                        <div
                            style="background: linear-gradient(to top, #4a148c, transparent); height:100%; width:100%; display:flex; flex-direction:column; justify-content:flex-end; padding:30px;">
                            <h1 style="font-size: 40px; margin-bottom: 10px;">Productivity Tools</h1>
                            <p style="opacity: 0.9; max-width: 500px; margin-bottom: 20px;">Upgrade your workflow.</p>
                            <button
                                style="padding: 12px 30px; border: none; background: white; color: #4a148c; font-weight: 700; border-radius: 8px; cursor: pointer; width:fit-content;">Explore</button>
                        </div>
                    </div>
                </div>
                <div class="right-column-box"
                    style="background: linear-gradient(135deg, #667eea, #764ba2); color:white;">
                    <h3 style="margin-bottom:10px;">Featured</h3>
                    <div style="font-size: 60px; text-align:center; margin-top:50px;"><i class="fa-brands fa-figma"></i>
                    </div>
                    <p style="text-align:center; margin-top:10px;">Figma</p>
                </div>
            </div>

            <div class="section-header">Social Networking Apps <i class="fa-solid fa-chevron-right"></i></div>
            <div class="app-list-grid">
                <div class="app-list-item">
                    <img src="https://cdn-icons-png.flaticon.com/512/174/174855.png" class="app-icon-lg">
                    <div class="app-details">
                        <div class="app-name">Instagram</div>
                        <div class="app-meta"><i class="fa-solid fa-star"></i> 4.5 | Social</div>
                    </div>
                    <div class="app-price">Free</div>
                </div>
                <div class="app-list-item">
                    <img src="https://cdn-icons-png.flaticon.com/512/5968/5968764.png" class="app-icon-lg">
                    <div class="app-details">
                        <div class="app-name">Facebook</div>
                        <div class="app-meta"><i class="fa-solid fa-star"></i> 4.1 | Social</div>
                    </div>
                    <div class="app-price">Free</div>
                </div>
                <div class="app-list-item">
                    <img src="https://cdn-icons-png.flaticon.com/512/2111/2111463.png" class="app-icon-lg">
                    <div class="app-details">
                        <div class="app-name">TikTok</div>
                        <div class="app-meta"><i class="fa-solid fa-star"></i> 4.6 | Video</div>
                    </div>
                    <div class="app-price">Free</div>
                </div>
                <div class="app-list-item">
                    <img src="https://cdn-icons-png.flaticon.com/512/3670/3670051.png" class="app-icon-lg">
                    <div class="app-details">
                        <div class="app-name">WhatsApp</div>
                        <div class="app-meta"><i class="fa-solid fa-star"></i> 4.8 | Chat</div>
                    </div>
                    <div class="app-price">Free</div>
                </div>
                <div class="app-list-item">
                    <img src="https://cdn-icons-png.flaticon.com/512/3670/3670151.png" class="app-icon-lg">
                    <div class="app-details">
                        <div class="app-name">Twitter</div>
                        <div class="app-meta"><i class="fa-solid fa-star"></i> 4.0 | News</div>
                    </div>
                    <div class="app-price">Free</div>
                </div>
                <div class="app-list-item">
                    <img src="https://cdn-icons-png.flaticon.com/512/3670/3670147.png" class="app-icon-lg">
                    <div class="app-details">
                        <div class="app-name">YouTube</div>
                        <div class="app-meta"><i class="fa-solid fa-star"></i> 4.9 | Video</div>
                    </div>
                    <div class="app-price">Free</div>
                </div>
            </div>
        </div>