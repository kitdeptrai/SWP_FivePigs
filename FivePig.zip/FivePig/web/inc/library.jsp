<%-- 
    Document   : library
    Created on : Feb 2, 2026, 9:19:25 AM
    Author     : kiet
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<div class="content-section">
            <h2 style="margin-bottom: 20px;">My Library</h2>
            <div class="library-grid">
                <div class="lib-card">
                    <div class="lib-thumb bg-mc"><i class="fa-solid fa-cube"></i></div>
                    <div class="lib-info">
                        <h4>Minecraft</h4>
                        <p style="font-size:12px;color:green">Installed</p>
                    </div>
                </div>
                <div class="lib-card">
                    <div class="lib-thumb bg-cod"><i class="fa-solid fa-gun"></i></div>
                    <div class="lib-info">
                        <h4>Call of Duty</h4>
                        <p style="font-size:12px;color:orange">Update</p>
                    </div>
                </div>
                <div class="lib-card">
                    <div class="lib-thumb bg-music"><i class="fa-brands fa-apple"></i></div>
                    <div class="lib-info">
                        <h4>Apple Music</h4>
                        <p style="font-size:12px;color:#888">Cloud</p>
                    </div>
                </div>
            </div>
        </div>