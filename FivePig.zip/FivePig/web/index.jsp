<%--
    Document   : index
    Created on : Feb 2, 2026, 12:51:29 AM
    Author     : kiet
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIVEPIGS Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/style.css">
</head>
<body>

    <jsp:include page="UI/sidebar.jsp" />

    <div class="main-content">
        <jsp:include page="UI/header.jsp" />

        <%
            String pageName = request.getParameter("page");
            if (pageName == null || pageName.isEmpty()) {
                pageName = "home"; // Mặc định là home
            }

            String contentPage = "home";
            if ("games".equals(pageName)) {
                contentPage = "game";
            } else if ("apps".equals(pageName)) {
                contentPage = "inc/app.jsp";
            } else if ("library".equals(pageName)) {
                contentPage = "inc/library.jsp"; // (Tùy chọn nếu bạn tạo file này)
            }
        %>

        <jsp:include page="<%= contentPage %>" />
    </div>

    <script>
        function toggleList(page, type) {
            const btnT = document.getElementById(page + '-trend');
            const btnB = document.getElementById(page + '-best');
            const listT = document.getElementById(page + '-list-trend');
            const listB = document.getElementById(page + '-list-best');

            if (type === 'trend') {
                btnT.classList.add('active'); btnB.classList.remove('active');
                listT.style.display = 'block'; listB.style.display = 'none';
            } else {
                btnB.classList.add('active'); btnT.classList.remove('active');
                listB.style.display = 'block'; listT.style.display = 'none';
            }
        }
    </script>
</body>
</html>