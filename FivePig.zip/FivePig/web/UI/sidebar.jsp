<%--
    Document   : sidebar
    Created on : Feb 1, 2026, 11:40:27 PM
    Author     : kiet
--%>

<%@page pageEncoding="UTF-8"%>
<% String p = request.getParameter("page"); if(p==null) p="home"; %>

<div class="sidebar">
    <div class="logo">
        <img src="img/logo.png" alt="Logo">
        <span class="logo-text">FIVEPIGS</span>
    </div>

    <a href="index.jsp?page=home" class="menu-item <%= p.equals("home")?"active":"" %>">
        <i class="fa-solid fa-house"></i> Home
    </a>

    <a href="index.jsp?page=games" class="menu-item <%= p.equals("games")?"active":"" %>">
        <i class="fa-solid fa-gamepad"></i> Games
    </a>

    <a href="index.jsp?page=apps" class="menu-item <%= p.equals("apps")?"active":"" %>">
        <i class="fa-solid fa-cubes"></i> Apps
    </a>

    <a href="index.jsp?page=library" class="menu-item <%= p.equals("library")?"active":"" %>">
        <i class="fa-solid fa-book-open"></i> Library
    </a>

    <div class="sidebar-footer">
        <div class="menu-item"><i class="fa-regular fa-newspaper"></i> News</div>
        <div class="menu-item"><i class="fa-solid fa-circle-info"></i> About</div>
    </div>
</div>