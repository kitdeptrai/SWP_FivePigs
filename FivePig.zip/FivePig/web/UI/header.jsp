<%--
    Document   : header
    Created on : Feb 1, 2026, 11:40:58 PM
    Author     : kiet
--%>

<%@page pageEncoding="UTF-8"%>
<div class="header">
    <div class="search-group">
        <i class="fa-solid fa-magnifying-glass" style="color: #b2bec3;"></i>
        <input type="text" placeholder="Search apps, games...">
    </div>

    <div class="user-actions">
        <div class="icon-btn"><i class="fa-regular fa-bell"></i></div>
        <div class="avatar">
            <img src="https://ui-avatars.com/api/?name=User&background=6c5ce7&color=fff">
        </div>
    </div>
</div>